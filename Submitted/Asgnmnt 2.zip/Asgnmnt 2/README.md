Animation of a bird flying

